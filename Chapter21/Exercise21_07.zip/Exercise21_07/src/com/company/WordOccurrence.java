package com.company;

public class WordOccurrence implements Comparable<WordOccurrence>{
    int count;
    String word;
    WordOccurrence(int count, String word){
        this.count = count;
        this.word = word;
    }

    @Override
    public String toString(){
        return word + ": " + count;
    }

    @Override
    public int compareTo(WordOccurrence w) {
        if (count < w.count){
            return -1;
        }
        else if (count > w.count){
            return 1;
        }
        else {
            return 0;
        }
    }
}
