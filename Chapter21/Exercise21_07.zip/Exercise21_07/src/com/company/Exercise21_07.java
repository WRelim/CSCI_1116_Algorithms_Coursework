package com.company;

import java.util.*;

public class Exercise21_07 {
	public static void main(String[] args) {
		// Set text in a string
		String text = "Good morning. Have a good class. " +
			"Have a good visit. Have fun!";

		// Create a TreeMap to hold words as key and count as value
		HashMap<String, Integer> map = new HashMap<>();

		String[] words = text.split("[\\s+\\p{P}]");
		for (int i = 0; i < words.length; i++) {
			String key = words[i].toLowerCase();

			if (key.length() > 0) {
				if (!map.containsKey(key)) {
					map.put(key, 1);
				}
				else {
					int value = map.get(key);
					value++;
					map.put(key, value);
				}
			}
		}

		Set<String> keySet = map.keySet();
		ArrayList<String> keyList = new ArrayList<String>(keySet);

		Collection<Integer> values = map.values();
		ArrayList<Integer> valueList = new ArrayList<>(values);

		List<WordOccurrence> wordOccurrences = new ArrayList<>();
		for (int loop = 0; wordOccurrences.size() < keyList.size(); loop++) {
			wordOccurrences.add(new WordOccurrence(valueList.get(loop), keyList.get(loop)));
		}

		Collections.sort(wordOccurrences);
		for (int loop = wordOccurrences.size() - 1;0 <= loop; loop--) {
			System.out.println(wordOccurrences.get(loop));
		}

		// Display key and value for each entry
//		map.forEach((k, v) -> System.out.println(k + "\t" + v));
	}
}