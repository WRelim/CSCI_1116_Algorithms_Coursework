package com.company;

import java.util.LinkedList;

public class GenericQueue<E> extends LinkedList {
    LinkedList list;

    GenericQueue(LinkedList list){
        this.list = list;
    }

    public void enqueue(E e) {
        list.addLast(e);
    }

    public E dequeue() {
        return (E) list.removeFirst();
    }

    public int getSize() {
        return list.size();
    }

    @Override
    public String toString() {
        return "Queue: " + list.toString();
    }
}
