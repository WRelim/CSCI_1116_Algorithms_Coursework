package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        LinkedList<Character> count = new LinkedList<>();
        LinkedList<Character> list = new LinkedList<>();

        System.out.println("Enter a string: ");
        String user = input.nextLine();

        for (int i = 0; i < user.length(); i++) {
            if (1 < list.size() && user.charAt(i) <= list.getLast() && list.contains(user.charAt(i))) {
                list.clear();
            }
            list.add(user.charAt(i));
            if (list.size() > count.size()) {
                count.clear();
                count.addAll(list);
            }
        }
        System.out.print("Maximum consecutive substring is: ");
        for (int i = 0; i < count.size(); i++) {
            System.out.print(count.get(i));
        }
    }
}
