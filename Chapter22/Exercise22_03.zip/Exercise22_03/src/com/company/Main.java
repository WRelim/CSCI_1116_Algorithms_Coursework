package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the first string: ");
        String user1 = input.nextLine();
        System.out.println("Enter the second string: ");
        String user2 = input.nextLine();
        if (user1.length() < user2.length()) {
            System.out.println("The second string is larger than the first.");
        }
        else {
            if (user1.contains(user2)) {
                for (int i = 0; i < user1.length(); i++) {
                    if (user1.charAt(i) == user2.charAt(0)){
                        System.out.println("Matched at index " + i);
                        i = user1.length();
                    }
                }
            }
        }
    }
}
